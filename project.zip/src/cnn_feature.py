"""
CNN 特征提取模块：把图像压缩成低维特征向量
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class FeatureExtractor(nn.Module):
    """
    轻量级 CNN 特征提取器
    输入：[batch, 1, 28, 28] 灰度图像
    输出：[batch, 32] 特征向量
    """

    def __init__(self, feature_dim=32):
        super(FeatureExtractor, self).__init__()

        # 卷积层：提取局部特征
        self.conv1 = nn.Conv2d(1, 16, kernel_size=3, padding=1)  # 1→16通道
        self.conv2 = nn.Conv2d(16, 32, kernel_size=3, padding=1)  # 16→32通道
        self.conv3 = nn.Conv2d(32, 64, kernel_size=3, padding=1)  # 32→64通道

        # 批归一化：加速训练，防止梯度消失
        self.bn1 = nn.BatchNorm2d(16)
        self.bn2 = nn.BatchNorm2d(32)
        self.bn3 = nn.BatchNorm2d(64)

        # 池化层：降维，保留主要特征
        self.pool = nn.MaxPool2d(2, 2)  # 28×28 → 14×14 → 7×7

        # Dropout：防止过拟合
        self.dropout = nn.Dropout(0.3)

        # 全连接层：把特征图展平并压缩到指定维度
        # 经过3次池化：28→14→7→3（取整），64通道×3×3=576
        self.fc1 = nn.Linear(64 * 3 * 3, 128)
        self.fc2 = nn.Linear(128, feature_dim)

        self.feature_dim = feature_dim

    def forward(self, x):
        # 卷积 + 激活 + 池化
        x = self.pool(F.relu(self.bn1(self.conv1(x))))  # [B,16,14,14]
        x = self.pool(F.relu(self.bn2(self.conv2(x))))  # [B,32,7,7]
        x = self.pool(F.relu(self.bn3(self.conv3(x))))  # [B,64,3,3]

        # 展平
        x = x.view(x.size(0), -1)  # [B, 64*3*3=576]

        # 全连接压缩
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.fc2(x)  # [B, 32] 特征向量

        return x


class CNNClassifier(nn.Module):
    """
    完整的 CNN 分类器（用于训练阶段）
    在 FeatureExtractor 后加一个分类头
    """

    def __init__(self, feature_dim=32, num_classes=2):
        super(CNNClassifier, self).__init__()
        self.feature_extractor = FeatureExtractor(feature_dim)
        self.classifier = nn.Linear(feature_dim, num_classes)

    def forward(self, x):
        features = self.feature_extractor(x)
        output = self.classifier(features)
        return output, features  # 返回分类结果 + 特征向量

    def get_features(self, x):
        """仅提取特征，不做分类"""
        return self.feature_extractor(x)


def test_cnn():
    """测试 CNN 模块"""
    print("=" * 50)
    print("测试 CNN 特征提取器")
    print("=" * 50)

    # 创建模型
    model = CNNClassifier(feature_dim=32)

    # 模拟输入：4张28×28的灰度图
    dummy_input = torch.randn(4, 1, 28, 28)

    # 前向传播
    output, features = model(dummy_input)

    print(f"输入形状：{dummy_input.shape}")
    print(f"分类输出形状：{output.shape}")  # [4, 2]（正常/异常二分类）
    print(f"特征向量形状：{features.shape}")  # [4, 32]
    print(f"特征向量示例（第1张图）：\n{features[0].detach().numpy()[:10]}...")  # 显示前10维

    # 统计参数量
    total_params = sum(p.numel() for p in model.parameters())
    print(f"模型总参数量：{total_params:,}")

    return model


if __name__ == '__main__':
    test_cnn()