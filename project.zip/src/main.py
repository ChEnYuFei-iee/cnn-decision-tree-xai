"""
主程序：工业多模态缺陷检测中的"可解释AI"系统
CNN（眼睛）提取特征 + 决策树（大脑）做可解释判断
"""
import os
import torch
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
matplotlib.rcParams['axes.unicode_minus'] = False
from torchvision import transforms

from src.cnn_feature import CNNClassifier
from src.data_loader import IndustrialDefectDataset
import joblib

# 路径配置
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(BASE_DIR, 'models')
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# 类别名称
CLASS_NAMES = {0: '正常 (Normal)', 1: '异常 (Defect)'}


def load_models():
    """加载训练好的 CNN 和决策树模型"""
    print("=" * 60)
    print("加载模型...")
    print("=" * 60)

    # 加载 CNN
    cnn = CNNClassifier(feature_dim=32).to(DEVICE)
    cnn_path = os.path.join(MODELS_DIR, 'cnn_best.pth')
    cnn.load_state_dict(torch.load(cnn_path, map_location=DEVICE))
    cnn.eval()
    print(f"✓ CNN 模型已加载: {cnn_path}")

    # 加载决策树
    dt_path = os.path.join(MODELS_DIR, 'decision_tree.pkl')
    dt = joblib.load(dt_path)
    print(f"✓ 决策树模型已加载: {dt_path}")

    return cnn, dt


def explain_prediction(dt, features, feature_names=None):
    """
    解释决策树的判断过程：走了哪条规则
    """
    if feature_names is None:
        feature_names = [f"Feature_{i}" for i in range(32)]

    # 获取决策路径
    node_indicator = dt.decision_path(features.reshape(1, -1))
    leaf_id = dt.apply(features.reshape(1, -1))[0]

    # 获取路径上的节点
    node_index = node_indicator.indices[node_indicator.indptr[0]:
                                        node_indicator.indptr[1]]

    explanation = []
    for node_id in node_index:
        if node_id == leaf_id:
            # 叶子节点：最终判断
            class_probs = dt.tree_.value[node_id][0]
            class_probs = class_probs / class_probs.sum()
            pred_class = class_probs.argmax()
            confidence = class_probs.max()
            explanation.append(f"→ 最终判断: {CLASS_NAMES[pred_class]} (置信度: {confidence:.2%})")
        else:
            # 内部节点：判断条件
            feature = dt.tree_.feature[node_id]
            threshold = dt.tree_.threshold[node_id]
            if features[feature] <= threshold:
                explanation.append(f"  检查: {feature_names[feature]} <= {threshold:.3f} → 满足")
            else:
                explanation.append(f"  检查: {feature_names[feature]} > {threshold:.3f} → 满足")

    return explanation, pred_class, confidence


def predict_single_image(cnn, dt, image_tensor, true_label=None):
    """
    对单张图片进行预测并解释
    """
    # CNN 提取特征
    with torch.no_grad():
        image_tensor = image_tensor.unsqueeze(0).to(DEVICE)  # [1, 1, 28, 28]
        features = cnn.get_features(image_tensor)
        features = features.cpu().numpy()[0]  # [32]

    # 决策树预测
    prediction = dt.predict(features.reshape(1, -1))[0]
    proba = dt.predict_proba(features.reshape(1, -1))[0]

    # 获取解释
    feature_names = [f"CNN_Feature_{i:02d}" for i in range(32)]
    explanation, pred_class, confidence = explain_prediction(dt, features, feature_names)

    # 打印结果
    print("\n" + "=" * 60)
    print("预测结果")
    print("=" * 60)
    if true_label is not None:
        print(f"真实标签: {CLASS_NAMES[true_label]}")
    print(f"预测结果: {CLASS_NAMES[prediction]}")
    print(f"置信度:   {proba[prediction]:.2%}")
    print(f"概率分布: 正常={proba[0]:.2%}, 异常={proba[1]:.2%}")

    print("\n" + "-" * 60)
    print("决策路径（可解释AI核心）")
    print("-" * 60)
    for step in explanation:
        print(step)

    print("-" * 60)
    print("关键特征值（前5个最重要的）")
    print("-" * 60)
    importances = dt.feature_importances_
    top5 = np.argsort(importances)[-5:][::-1]
    for i, idx in enumerate(top5, 1):
        print(f"  {i}. CNN_Feature_{idx:02d}: {features[idx]:.3f} (重要性: {importances[idx]:.4f})")

    return prediction, proba, features


def visualize_result(image, prediction, proba, true_label=None):
    """可视化预测结果"""
    plt.figure(figsize=(6, 6))

    # 反归一化显示
    img = image.squeeze().numpy() * 0.5 + 0.5

    plt.imshow(img, cmap='gray')

    title = f"Prediction: {CLASS_NAMES[prediction]}\n"
    title += f"Confidence: {proba[prediction]:.1%}"
    if true_label is not None:
        title += f"\nTrue: {CLASS_NAMES[true_label]}"
        color = 'green' if prediction == true_label else 'red'
    else:
        color = 'blue'

    plt.title(title, color=color, fontsize=12)
    plt.axis('off')
    plt.tight_layout()

    save_path = os.path.join(BASE_DIR, 'prediction_result.png')
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.show()
    print(f"\n可视化结果已保存: {save_path}")

    return save_path


def main():
    print("\n" + "=" * 60)
    print("工业多模态缺陷检测 - 可解释AI系统")
    print("CNN (Feature Extractor) + Decision Tree (Explainable)")
    print("=" * 60)

    # 加载模型
    cnn, dt = load_models()

    # 加载测试数据
    print("\n加载测试数据...")
    test_dataset = IndustrialDefectDataset(train=False, data_dir=os.path.join(BASE_DIR, 'data', 'raw'))

    # 随机选5张图片进行预测演示
    np.random.seed(42)
    sample_indices = np.random.choice(len(test_dataset), 5, replace=False)

    correct = 0
    for i, idx in enumerate(sample_indices, 1):
        print(f"\n{'#' * 60}")
        print(f"样本 #{i}/5 (索引: {idx})")
        print(f"{'#' * 60}")

        image, label = test_dataset[idx]
        pred, proba, features = predict_single_image(cnn, dt, image, true_label=label)

        if pred == label:
            correct += 1
            print(f"\n✓ 预测正确!")
        else:
            print(f"\n✗ 预测错误!")

        # 可视化第一张
        if i == 1:
            visualize_result(image, pred, proba, true_label=label)

    # 统计
    print(f"\n{'=' * 60}")
    print(f"演示完成: {correct}/5 预测正确")
    print(f"{'=' * 60}")
    print("\n系统特点:")
    print("  1. CNN 自动提取图像特征（无需人工设计）")
    print("  2. 决策树提供人类可读的决策规则")
    print("  3. 每条判断都有明确的路径和置信度")
    print("  4. 满足工业场景对可解释性的要求")


if __name__ == '__main__':
    main()