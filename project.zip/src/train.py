"""
训练脚本：训练 CNN 分类器，并提取特征保存供决策树使用
"""
import os
import torch
import torch.nn as nn
import torch.optim as optim
from tqdm import tqdm
import numpy as np

from cnn_feature import CNNClassifier
from data_loader import get_data_loaders, DATA_DIR

# 配置参数
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"使用设备：{DEVICE}")

EPOCHS = 5  # 训练轮数（5轮足够演示）
BATCH_SIZE = 64
LR = 0.001  # 学习率
FEATURE_DIM = 32


def train_epoch(model, loader, optimizer, criterion):
    """训练一个 epoch"""
    model.train()
    total_loss = 0
    correct = 0
    total = 0

    for images, labels in tqdm(loader, desc="训练中"):
        images, labels = images.to(DEVICE), labels.to(DEVICE)

        # 前向传播
        optimizer.zero_grad()
        outputs, _ = model(images)
        loss = criterion(outputs, labels)

        # 反向传播
        loss.backward()
        optimizer.step()

        # 统计
        total_loss += loss.item()
        _, predicted = torch.max(outputs, 1)
        correct += (predicted == labels).sum().item()
        total += labels.size(0)

    avg_loss = total_loss / len(loader)
    accuracy = correct / total
    return avg_loss, accuracy


def evaluate(model, loader, criterion):
    """评估模型"""
    model.eval()
    total_loss = 0
    correct = 0
    total = 0

    with torch.no_grad():
        for images, labels in tqdm(loader, desc="评估中"):
            images, labels = images.to(DEVICE), labels.to(DEVICE)
            outputs, _ = model(images)
            loss = criterion(outputs, labels)

            total_loss += loss.item()
            _, predicted = torch.max(outputs, 1)
            correct += (predicted == labels).sum().item()
            total += labels.size(0)

    avg_loss = total_loss / len(loader)
    accuracy = correct / total
    return avg_loss, accuracy


def extract_features(model, loader):
    """
    提取特征向量
    返回：features [N, 32], labels [N]
    """
    model.eval()
    all_features = []
    all_labels = []

    with torch.no_grad():
        for images, labels in tqdm(loader, desc="提取特征"):
            images = images.to(DEVICE)
            features = model.get_features(images)

            all_features.append(features.cpu().numpy())
            all_labels.append(labels.numpy())

    features = np.concatenate(all_features, axis=0)
    labels = np.concatenate(all_labels, axis=0)

    return features, labels


def main():
    print("=" * 60)
    print("阶段四：训练 CNN 并提取特征")
    print("=" * 60)

    # 加载数据
    train_loader, test_loader = get_data_loaders(batch_size=BATCH_SIZE)

    # 创建模型
    model = CNNClassifier(feature_dim=FEATURE_DIM).to(DEVICE)
    criterion = nn.CrossEntropyLoss()  # 交叉熵损失（分类任务标准）
    optimizer = optim.Adam(model.parameters(), lr=LR)

    print(f"\n模型已创建，开始训练 {EPOCHS} 轮...")

    # 训练循环
    best_acc = 0
    for epoch in range(EPOCHS):
        print(f"\n--- Epoch {epoch + 1}/{EPOCHS} ---")

        train_loss, train_acc = train_epoch(model, train_loader, optimizer, criterion)
        test_loss, test_acc = evaluate(model, test_loader, criterion)

        print(f"训练损失: {train_loss:.4f} | 训练准确率: {train_acc:.4f}")
        print(f"测试损失: {test_loss:.4f} | 测试准确率: {test_acc:.4f}")

        # 保存最佳模型
        if test_acc > best_acc:
            best_acc = test_acc
            model_path = os.path.join(os.path.dirname(DATA_DIR), '..', 'models', 'cnn_best.pth')
            os.makedirs(os.path.dirname(model_path), exist_ok=True)
            torch.save(model.state_dict(), model_path)
            print(f"✓ 保存最佳模型（准确率: {best_acc:.4f}）")

    # 加载最佳模型，提取特征
    print("\n" + "=" * 60)
    print("提取特征向量供决策树使用...")
    print("=" * 60)

    model.load_state_dict(torch.load(model_path))

    # 提取训练集和测试集特征
    train_features, train_labels = extract_features(model, train_loader)
    test_features, test_labels = extract_features(model, test_loader)

    # 保存为 numpy 文件
    processed_dir = os.path.join(os.path.dirname(DATA_DIR), 'processed')
    os.makedirs(processed_dir, exist_ok=True)

    np.save(os.path.join(processed_dir, 'train_features.npy'), train_features)
    np.save(os.path.join(processed_dir, 'train_labels.npy'), train_labels)
    np.save(os.path.join(processed_dir, 'test_features.npy'), test_features)
    np.save(os.path.join(processed_dir, 'test_labels.npy'), test_labels)

    print(f"\n✓ 特征已保存到 {processed_dir}/")
    print(f"  训练集特征：{train_features.shape}")
    print(f"  测试集特征：{test_features.shape}")
    print(f"  特征维度：{FEATURE_DIM}（供决策树使用）")

    # 展示一个特征向量示例
    print(f"\n特征向量示例（第1个样本的前10维）：")
    print(f"  {train_features[0][:10]}")


if __name__ == '__main__':
    main()