"""
决策树模块：基于 CNN 提取的特征进行可解释分类
"""
import os
import numpy as np
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import matplotlib.pyplot as plt
from sklearn import tree

# 路径配置
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROCESSED_DIR = os.path.join(BASE_DIR, 'data', 'processed')
MODELS_DIR = os.path.join(BASE_DIR, 'models')


def load_features():
    """加载 CNN 提取的特征"""
    train_features = np.load(os.path.join(PROCESSED_DIR, 'train_features.npy'))
    train_labels = np.load(os.path.join(PROCESSED_DIR, 'train_labels.npy'))
    test_features = np.load(os.path.join(PROCESSED_DIR, 'test_features.npy'))
    test_labels = np.load(os.path.join(PROCESSED_DIR, 'test_labels.npy'))

    print(f"加载特征数据：")
    print(f"  训练集：{train_features.shape}")
    print(f"  测试集：{test_features.shape}")

    return train_features, train_labels, test_features, test_labels


def train_decision_tree(max_depth=5):
    """
    训练决策树
    max_depth: 树的最大深度，控制复杂度（越小越简单，越易解释）
    """
    # 加载数据
    X_train, y_train, X_test, y_test = load_features()

    # 为了演示速度，从训练集采样一部分（决策树不需要海量数据）
    # 工业场景中，通常用 CNN 特征 + 少量标注样本即可训练决策树
    sample_size = min(10000, len(X_train))
    indices = np.random.choice(len(X_train), sample_size, replace=False)
    X_train_sample = X_train[indices]
    y_train_sample = y_train[indices]

    print(f"\n使用 {sample_size} 个样本训练决策树（max_depth={max_depth}）...")

    # 创建决策树
    dt = DecisionTreeClassifier(
        max_depth=max_depth,  # 限制深度，防止过拟合，保证可解释性
        min_samples_leaf=50,  # 叶子节点最少样本数，防止过拟合
        criterion='gini',  # 分裂标准：基尼不纯度
        random_state=42
    )

    # 训练
    dt.fit(X_train_sample, y_train_sample)

    # 评估
    y_pred = dt.predict(X_test)
    acc = accuracy_score(y_test, y_pred)

    print(f"\n{'=' * 50}")
    print(f"决策树评估结果")
    print(f"{'=' * 50}")
    print(f"测试集准确率：{acc:.4f}")
    print(f"\n分类报告：")
    print(classification_report(y_test, y_pred, target_names=['正常', '异常']))

    # 保存模型
    import joblib
    os.makedirs(MODELS_DIR, exist_ok=True)
    joblib.dump(dt, os.path.join(MODELS_DIR, 'decision_tree.pkl'))
    print(f"\n✓ 决策树模型已保存")

    return dt, X_test, y_test


def explain_tree(dt, feature_names=None):
    """
    生成决策树的可解释规则文本
    """
    if feature_names is None:
        feature_names = [f"CNN特征_{i}" for i in range(32)]

    print(f"\n{'=' * 50}")
    print(f"决策树规则（人类可读）")
    print(f"{'=' * 50}")

    # 文本形式的规则
    tree_rules = export_text(dt, feature_names=feature_names)
    print(tree_rules[:2000] + "..." if len(tree_rules) > 2000 else tree_rules)

    # 保存到文件
    with open(os.path.join(MODELS_DIR, 'tree_rules.txt'), 'w', encoding='utf-8') as f:
        f.write("工业缺陷检测 - 决策树决策规则\n")
        f.write("=" * 60 + "\n\n")
        f.write("规则说明：\n")
        f.write("- 每个 if 代表一个判断条件\n")
        f.write("- 最终 class: 0 = 正常，1 = 异常\n")
        f.write("- 数值表示该叶子节点的样本分布\n\n")
        f.write(tree_rules)

    print(f"\n✓ 完整规则已保存到 models/tree_rules.txt")

    # 显示特征重要性（哪些 CNN 特征最被决策树看重）
    importances = dt.feature_importances_
    top_indices = np.argsort(importances)[-10:][::-1]  # 前10个重要特征

    print(f"\n{'=' * 50}")
    print(f"最重要的 10 个 CNN 特征（决策树视角）")
    print(f"{'=' * 50}")
    for i, idx in enumerate(top_indices, 1):
        print(f"  {i}. {feature_names[idx]}: 重要性 {importances[idx]:.4f}")

    return importances


def visualize_tree(dt, feature_names=None):
    """
    可视化决策树结构
    """
    if feature_names is None:
        feature_names = [f"特征_{i}" for i in range(32)]

    plt.figure(figsize=(20, 12))
    tree.plot_tree(
        dt,
        feature_names=feature_names,
        class_names=['Normal', 'Defect'],
        filled=True,  # 节点着色
        rounded=True,  # 圆角节点
        fontsize=8,
        max_depth=3  # 只画前3层，太多会看不清
    )
    plt.title("Industrial Defect Detection - Decision Tree (Top 3 Layers)", fontsize=14)
    plt.tight_layout()

    save_path = os.path.join(MODELS_DIR, 'decision_tree.png')
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.show()
    print(f"\n✓ 决策树可视化已保存：{save_path}")


def main():
    print("=" * 60)
    print("阶段五：训练可解释决策树")
    print("=" * 60)

    # 训练决策树
    dt, X_test, y_test = train_decision_tree(max_depth=5)

    # 生成可解释规则
    feature_names = [f"CNN特征_{i:02d}" for i in range(32)]
    importances = explain_tree(dt, feature_names)

    # 可视化
    visualize_tree(dt, feature_names)

    print(f"\n{'=' * 60}")
    print("阶段五完成！")
    print(f"{'=' * 60}")
    print("输出文件：")
    print(f"  - models/decision_tree.pkl     (模型文件)")
    print(f"  - models/tree_rules.txt        (文本规则)")
    print(f"  - models/decision_tree.png     (可视化树图)")


if __name__ == '__main__':
    main()