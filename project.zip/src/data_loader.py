"""
数据加载模块：下载 Fashion-MNIST 并改造为"工业缺陷检测"数据集
"""
import os
import torch
from torchvision import datasets, transforms
from torch.utils.data import Dataset, DataLoader

# 获取项目根目录（这个文件所在目录的上级）
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, 'data', 'raw')


class IndustrialDefectDataset(Dataset):
    """
    工业缺陷数据集
    - 正常类：T恤(0)、裤子(1) → 标签 0
    - 异常类：其他8类 → 标签 1
    """

    def __init__(self, train=True, data_dir=DATA_DIR):
        # 确保目录存在（兼容Windows的写法）
        if not os.path.exists(data_dir):
            os.makedirs(data_dir)

        # 定义图像预处理：转为Tensor并归一化
        transform = transforms.Compose([
            transforms.ToTensor(),  # 转为 [0,1] 范围的Tensor
            transforms.Normalize((0.5,), (0.5,))  # 归一化到 [-1,1]
        ])

        # 自动下载 Fashion-MNIST
        self.mnist = datasets.FashionMNIST(
            root=data_dir,
            train=train,
            download=True,
            transform=transform
        )

        # 正常类索引
        self.normal_classes = [0, 1]  # T恤, 裤子

        # 筛选并重新标记数据
        self.data = []
        self.labels = []

        for img, label in self.mnist:
            if label in self.normal_classes:
                self.data.append(img)
                self.labels.append(0)  # 正常
            else:
                self.data.append(img)
                self.labels.append(1)  # 异常

        print(f"{'训练' if train else '测试'}集加载完成："
              f"正常样本 {self.labels.count(0)} 个，"
              f"异常样本 {self.labels.count(1)} 个")

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx], self.labels[idx]


def get_data_loaders(batch_size=64, data_dir=DATA_DIR):
    """
    创建训练集和测试集的 DataLoader
    """
    train_dataset = IndustrialDefectDataset(train=True, data_dir=data_dir)
    test_dataset = IndustrialDefectDataset(train=False, data_dir=data_dir)

    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True  # 训练时打乱顺序
    )
    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False  # 测试时不打乱
    )

    return train_loader, test_loader


if __name__ == '__main__':
    # 测试数据加载
    print("=" * 50)
    print("测试数据加载模块")
    print(f"数据目录：{DATA_DIR}")
    print("=" * 50)

    train_loader, test_loader = get_data_loaders(batch_size=64)

    # 取一个批次看看
    images, labels = next(iter(train_loader))
    print(f"\n一个批次的数据形状：{images.shape}")  # [64, 1, 28, 28]
    print(f"标签示例：{labels[:10]}")  # 前10个标签
    print(f"正常(0)/异常(1) 比例：{(labels == 0).sum().item()}/{(labels == 1).sum().item()}")